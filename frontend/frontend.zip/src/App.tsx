import { useState, useEffect } from 'react';
import TaskList from "./components/TaskList";
import TaskDashboard from "./components/TaskDashboard";
import UserList from "./components/UserList";
import NewUserModal from "./components/NewUserModal";
import NewTaskModal from "./components/NewTaskModal";
import Login from "./components/Login";
import Agenda from "./components/Agenda";
import ManagerDashboard from "./components/ManagerDashboard";
import SalesDashboard from "./components/SalesDashboard";
import NotificationBell from "./components/NotificationBell";
import AlertCenterBell from "./components/AlertCenterBell";
import GlobalSearch from './components/GlobalSearch';
import IntelligentAlerts from './components/IntelligentAlerts';
import ExecutiveDashboard from './components/ExecutiveDashboard';
import AvaliacoesLojas from './components/AvaliacoesLojas';
import AcessoRapidoAparelhos from './components/AcessoRapidoAparelhos';
import Home from "./components/home";
import DeptBulletin from "./components/DeptBulletin";
import FinanceModule from "./components/FinanceModule";
import ControleStone from "./components/ControleStone";
import RecebimentoCartao from "./components/RecebimentoCartao";
import StockModule from "./components/StockModule";
import PriceTablePage from './components/PriceTablePage';
import { EstoqueVendas } from './components/EstoqueVendas';
import EstoqueInteligente from './components/EstoqueInteligente';
import ComparativoAnual from './components/ComparativoAnual';
import AuditoriaLojas from './components/AuditoriaLojas';
import EstoqueDetalhado from './components/EstoqueDetalhado';
import SolicitacoesModule from './components/SolicitacoesModule';
import Stockout from './components/StockOut';
import ComparativosModule from './components/ComparativosModule';
import LeituraCartas from './components/LeituraCartas';
import FluxoComparativoModule from './components/FluxoComparativoModule';
import ComprasVendas from './components/ComprasVendas';
import Clark from './components/Clark';
import RhModule from './components/RhModule';
// NOVA IMPORTAÇÃO: Módulo de Contratos
import ContractAnalyzer from './components/ContractAnalyzer';
import OnlinePricesAgent from './components/OnlinePricesAgent';
import InventoryAuditModule from './components/InventoryAuditModule';
import InventoryAuditDashboard from './components/InventoryAuditDashboard';

import {
  FileText,
  CheckCircle,
  LayoutDashboard,
  Users,
  LogOut,
  Calendar,
  BarChart3,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Circle,
  Plus,
  TrendingUp,
  Home as HomeIcon,
  MessageSquare,
  DollarSign,
  Package,
  Menu,
  X,
  Tag,
  ShieldCheck,
} from 'lucide-react';

const DEFAULT_EXPANDED = {
  general: false,
  mine: false,
  info: false,
  stock: false,
  sales: false,
  finance: false,
  comparativos: false,
  executive: false,
};

const STORE_HOME_VIEW = 'home';

const SESSION_STORAGE_KEY = 'telefluxo_session_active';
const SESSION_LAST_ACTIVITY_KEY = 'telefluxo_last_activity';
const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutos sem atividade

function clearTelefluxoSession() {
  localStorage.removeItem('telefluxo_user');
  localStorage.removeItem('user');
  localStorage.removeItem('userId');
  localStorage.removeItem('telefluxo_user_id');
  sessionStorage.removeItem(SESSION_STORAGE_KEY);
  sessionStorage.removeItem(SESSION_LAST_ACTIVITY_KEY);
}

const STORE_ALLOWED_VIEWS = new Set([
  'home',
  'rh',
  'stock',
  'inventory_audit',
  'alertas_inteligentes',
  'estoque_detalhado',
  'estoque_vendas',
  'estoque_inteligente',
  'stockout',
  'sales_dash',
  'comparativo',
  'price_table',
  'agenda',
  'solicitacoes',
]);

function isStoreRole(userData: any): boolean {
  return String(userData?.role || '').trim().toUpperCase() === 'LOJA';
}

function getInitialViewForUser(userData: any): string {
  return isStoreRole(userData) ? STORE_HOME_VIEW : 'home';
}

function isViewAllowedForStore(view: string): boolean {
  return STORE_ALLOWED_VIEWS.has(view);
}

function App() {
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState('home');
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [expanded, setExpanded] = useState(DEFAULT_EXPANDED);
  const [mountedViews, setMountedViews] = useState<string[]>(['home']);

  useEffect(() => {
    try {
      const savedCollapsed = localStorage.getItem('telefluxo_sidebar_collapsed');
      if (savedCollapsed === 'true') setIsSidebarCollapsed(true);
    } catch (e) {
      console.error(e);
    }

    const savedUser = localStorage.getItem('telefluxo_user');
    const sessionActive = sessionStorage.getItem(SESSION_STORAGE_KEY) === '1';
    const lastActivity = Number(sessionStorage.getItem(SESSION_LAST_ACTIVITY_KEY) || 0);
    const sessionExpired = !lastActivity || Date.now() - lastActivity >= SESSION_TIMEOUT_MS;

    // Uma nova abertura do navegador/aba não possui sessionStorage e exige login.
    // Um simples refresh mantém a sessão, desde que ela não esteja expirada.
    if (savedUser && savedUser !== "undefined" && sessionActive && !sessionExpired) {
      try {
        const parsedUser = JSON.parse(savedUser);
        const initialView = getInitialViewForUser(parsedUser);
        setUser(parsedUser);
        setCurrentView(initialView);
        setMountedViews([initialView]);
        setExpanded(DEFAULT_EXPANDED);
        sessionStorage.setItem(SESSION_LAST_ACTIVITY_KEY, String(Date.now()));
      } catch (e) {
        clearTelefluxoSession();
      }
    } else {
      clearTelefluxoSession();
    }

    setIsLoading(false);
  }, []);

  useEffect(() => {
    const handleOpenModal = () => setIsNewTaskModalOpen(true);
    window.addEventListener('openNewTaskModal', handleOpenModal);
    return () => window.removeEventListener('openNewTaskModal', handleOpenModal);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('telefluxo_sidebar_collapsed', String(isSidebarCollapsed));
    } catch (e) {
      console.error(e);
    }
  }, [isSidebarCollapsed]);

  useEffect(() => {
    if (!user) return;

    let timeoutId: number | undefined;
    let lastRecordedAt = 0;

    const expireSession = () => {
      clearTelefluxoSession();
      setUser(null);
      setCurrentView('home');
      setMountedViews(['home']);
      setExpanded(DEFAULT_EXPANDED);
    };

    const scheduleExpiry = () => {
      if (timeoutId) window.clearTimeout(timeoutId);

      const lastActivity = Number(
        sessionStorage.getItem(SESSION_LAST_ACTIVITY_KEY) || Date.now()
      );
      const remaining = SESSION_TIMEOUT_MS - (Date.now() - lastActivity);

      if (remaining <= 0) {
        expireSession();
        return;
      }

      timeoutId = window.setTimeout(expireSession, remaining);
    };

    const registerActivity = () => {
      const now = Date.now();
      // Evita escrever no sessionStorage centenas de vezes por segundo em mousemove/scroll.
      if (now - lastRecordedAt < 5000) return;
      lastRecordedAt = now;
      sessionStorage.setItem(SESSION_LAST_ACTIVITY_KEY, String(now));
      scheduleExpiry();
    };

    const events: Array<keyof WindowEventMap> = [
      'mousedown',
      'keydown',
      'scroll',
      'touchstart',
      'mousemove',
    ];

    sessionStorage.setItem(SESSION_STORAGE_KEY, '1');
    sessionStorage.setItem(SESSION_LAST_ACTIVITY_KEY, String(Date.now()));
    scheduleExpiry();

    events.forEach((eventName) =>
      window.addEventListener(eventName, registerActivity, { passive: true })
    );

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        const lastActivity = Number(
          sessionStorage.getItem(SESSION_LAST_ACTIVITY_KEY) || 0
        );
        if (!lastActivity || Date.now() - lastActivity >= SESSION_TIMEOUT_MS) {
          expireSession();
        } else {
          scheduleExpiry();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      if (timeoutId) window.clearTimeout(timeoutId);
      events.forEach((eventName) =>
        window.removeEventListener(eventName, registerActivity)
      );
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [user?.id]);

  const userRole = String(user?.role || '').toUpperCase();
  const userEmail = String(user?.email || '').toLowerCase();
  const isAdmin = user?.isAdmin === true || Number(user?.isAdmin) === 1;

  const isManager =
    userRole.includes('GERENTE') ||
    userRole.includes('GESTOR');

  const isSamsungUser =
    userRole === 'SAMSUNG' ||
    userEmail === 'analista.samsungtelecel@gmail.com';

  const canViewSales = ['CEO', 'DIRETOR', 'LOJA'].includes(userRole) || (isAdmin && userRole !== 'LOJA');
  const canViewStock = ['CEO', 'DIRETOR', 'LOJA'].includes(userRole) || (isAdmin && userRole !== 'LOJA');
  const canViewFinance = ['CEO', 'DIRETOR', 'ADM'].includes(userRole) || (isAdmin && userRole !== 'LOJA');
  const canViewTeam = ['CEO', 'DIRETOR', 'ADM'].includes(userRole) || (isAdmin && userRole !== 'LOJA');
  const canViewComparativos = ['ADM', 'CEO'].includes(userRole) || (isAdmin && userRole !== 'LOJA') || isSamsungUser;
  const canViewExecutiveDashboard = userRole !== 'LOJA' && (userRole === 'ADM' || isAdmin);
  const canViewAuditDashboard = userRole !== 'LOJA' && (['ADM', 'ADMIN', 'CEO', 'DIRETOR'].includes(userRole) || isAdmin);
  const canUseClarkDiretoria = ['CEO', 'DIRETOR', 'DIRETORIA'].includes(userRole);

  const isStoreOnly = userRole === 'LOJA';

  useEffect(() => {
    if (!user || !isStoreOnly) return;

    if (!isViewAllowedForStore(currentView)) {
      setCurrentView(STORE_HOME_VIEW);
      setExpanded(DEFAULT_EXPANDED);
    }
  }, [user, isStoreOnly, currentView]);

  useEffect(() => {
    if (!user) return;

    setMountedViews((previous) =>
      previous.includes(currentView)
        ? previous
        : [...previous, currentView]
    );
  }, [currentView, user]);

  const handleLogout = () => {
    clearTelefluxoSession();
    setUser(null);
    setCurrentView('home');
    setMountedViews(['home']);
    setExpanded(DEFAULT_EXPANDED);
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    setIsMobileMenuOpen(false);
  };

  const handleSectionToggle = (key: keyof typeof DEFAULT_EXPANDED) => {
    if (isSidebarCollapsed) {
      setIsSidebarCollapsed(false);
      setExpanded({ ...DEFAULT_EXPANDED, [key]: true });
      return;
    }

    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const toggleSidebarCollapse = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };

  const viewTitles: Record<string, string> = {
    finance: 'CONTAS A PAGAR E RECEBER',
    controle_stone: 'CONCILIAÇÃO STONE',
    comparativos_pdf: 'MONTAR COMPARATIVO',
    comparativos_fluxo: 'FLUXO COMPARATIVO',
    comparativos_cartas: 'LEITURA DE CARTAS',
    comparativo: 'VENDAS ANUAIS',
    compras_vendas: 'COMPRAS X VENDAS',
    rh: 'RH',
    executive_dashboard: 'PAINEL DIRETORIA / RESUMO EXECUTIVO',
    avaliacoes_lojas: 'PAINEL DIRETORIA / AVALIAÇÕES DAS LOJAS',
    acesso_rapido_aparelhos: 'PAINEL DIRETORIA / ACESSO RÁPIDO',
    stock: 'CONTROLE DE ESTOQUE',
    inventory_audit: 'CONFERÊNCIA DE APARELHOS / BIPADOR',
    alertas_inteligentes: 'CENTRAL DE ALERTAS INTELIGENTES',
    estoque_detalhado: 'VISÃO DETALHADA DE ESTOQUE',
    estoque_vendas: 'ESTOQUE X VENDAS',
    estoque_inteligente: 'ESTOQUE INTELIGENTE',
    stockout: 'STOCKOUT',
    auditoria_lojas: 'AUDITORIA DE LOJAS',
    contract_analyzer: 'LEITOR DE CONTRATOS (CLARK JURÍDICA)', // Título da Nova Tela
    online_prices: 'CLARK IA / PREÇOS ONLINE',
  };

  const currentViewLabel =
    viewTitles[currentView] ||
    currentView.replace(/_/g, ' ').toUpperCase();

  if (isLoading) {
    return (
      <div className="h-screen bg-slate-900 flex items-center justify-center text-white font-black uppercase tracking-widest animate-pulse">
        Iniciando TeleFluxo...
      </div>
    );
  }

  if (!user) {
    return (
      <Login
        onLogin={(data: any) => {
          const initialView = getInitialViewForUser(data);
          setUser(data);
          localStorage.setItem('telefluxo_user', JSON.stringify(data));
          sessionStorage.setItem(SESSION_STORAGE_KEY, '1');
          sessionStorage.setItem(SESSION_LAST_ACTIVITY_KEY, String(Date.now()));
          setCurrentView(initialView);
          setMountedViews([initialView]);
          setExpanded(DEFAULT_EXPANDED);
        }}
      />
    );
  }

  const SubMenuItem = ({ label, view, active }: any) => {
    if (isSidebarCollapsed) return null;

    return (
      <div
        onClick={() => handleNavigate(view)}
        className={`pl-12 pr-4 py-2 cursor-pointer flex items-center gap-2 text-[11px] font-black uppercase tracking-tighter transition-all hover:text-white ${
          active ? 'text-orange-500' : 'text-slate-500'
        }`}
      >
        <Circle size={6} fill={active ? "currentColor" : "transparent"} />
        {label}
      </div>
    );
  };

  const NavButton = ({
    icon: Icon,
    label,
    active,
    onClick,
    hasChevron = false,
    chevronOpen = false,
    customClass = '',
  }: any) => (
    <div
      onClick={onClick}
      title={label}
      className={`p-3 rounded-xl cursor-pointer flex items-center ${
        isSidebarCollapsed ? 'justify-center' : 'justify-between'
      } transition-all ${
        active ? customClass : 'text-slate-400 hover:bg-slate-800'
      }`}
    >
      <div className={`flex items-center gap-3 font-bold text-sm ${isSidebarCollapsed ? 'justify-center' : ''}`}>
        <Icon size={18} />
        {!isSidebarCollapsed && <span>{label}</span>}
      </div>

      {!isSidebarCollapsed && hasChevron && (
        chevronOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />
      )}
    </div>
  );

  const renderViewContent = (view: string) => {
    if (view === 'home') {
      return <Home currentUser={user} onNavigate={handleNavigate} />;
    }

    if (
      view === 'executive_dashboard' &&
      canViewExecutiveDashboard
    ) {
      return <ExecutiveDashboard currentUser={user} />;
    }

    if (
      view === 'avaliacoes_lojas' &&
      canViewExecutiveDashboard
    ) {
      return <AvaliacoesLojas />;
    }

    if (
      view === 'acesso_rapido_aparelhos' &&
      canViewExecutiveDashboard
    ) {
      return <AcessoRapidoAparelhos currentUser={user} />;
    }

    if (view === 'alertas_inteligentes') {
      return (
        <IntelligentAlerts
          currentUser={user}
          onNavigateStock={() =>
            handleNavigate('estoque_detalhado')
          }
        />
      );
    }

    if (view === 'finance') return <FinanceModule />;
    if (view === 'controle_stone') return <ControleStone />;

    if (view === 'recebimento_cartao') {
      return <RecebimentoCartao currentUser={user} />;
    }

    if (view === 'comparativos_pdf') {
      return <ComparativosModule currentUser={user} />;
    }

    if (view === 'comparativos_fluxo') {
      return <FluxoComparativoModule currentUser={user} />;
    }

    if (view === 'comparativos_cartas') {
      return <LeituraCartas currentUser={user} />;
    }

    if (view === 'stock') return <StockModule currentUser={user} />;
    if (view === 'inventory_audit') return <InventoryAuditModule currentUser={user} />;
    if (view === 'inventory_audit_dashboard' && canViewAuditDashboard) return <InventoryAuditDashboard currentUser={user} />;

    if (view.startsWith('dept_')) {
      return (
        <DeptBulletin
          department={view.replace('dept_', '')}
          currentUser={user}
          isActive={view === currentView}
        />
      );
    }

    if (view === 'detail' && selectedTask) {
      return (
        <TaskDashboard
          task={selectedTask}
          currentUser={user}
          onBack={() => handleNavigate('home')}
        />
      );
    }

    if (view === 'agenda') {
      return <Agenda currentUser={user} />;
    }

    if (view === 'manager_dash') {
      return <ManagerDashboard currentUser={user} />;
    }

    if (view === 'sales_dash') return <SalesDashboard />;
    if (view === 'comparativo') return <ComparativoAnual />;
    if (view === 'estoque_vendas') return <EstoqueVendas />;
    if (view === 'estoque_inteligente') return <EstoqueInteligente currentUser={user} />;
    if (view === 'estoque_detalhado') return <EstoqueDetalhado />;
    if (view === 'stockout') return <Stockout currentUser={user} />;
    if (view === 'auditoria_lojas') return <AuditoriaLojas currentUser={user} />;
    if (view === 'price_table') return <PriceTablePage />;

    if (view === 'solicitacoes') {
      return <SolicitacoesModule currentUser={user} />;
    }

    if (view === 'compras_vendas' && isAdmin) {
      return <ComprasVendas />;
    }

    if (view === 'rh') {
      return <RhModule currentUser={user} />;
    }

    if (view === 'contract_analyzer' && canUseClarkDiretoria) {
      return <ContractAnalyzer currentUser={user} />;
    }

    if (view === 'online_prices' && canUseClarkDiretoria) {
      return <OnlinePricesAgent currentUser={user} />;
    }

    if (
      ['contract_analyzer', 'online_prices'].includes(view) &&
      !canUseClarkDiretoria
    ) {
      return <Home currentUser={user} onNavigate={handleNavigate} />;
    }

    if (view === 'team') {
      return (
        <div className="flex-1 p-4 md:p-8 overflow-y-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
              <h2 className="text-2xl font-black uppercase tracking-tight">
                Equipe Telecel
              </h2>

              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                Gestão de acessos e cargos do sistema.
              </p>
            </div>

            <button
              onClick={() => setIsUserModalOpen(true)}
              className="w-full md:w-auto bg-slate-900 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase flex gap-2 hover:bg-slate-800 shadow-lg transition-all active:scale-95 justify-center items-center"
            >
              <Plus size={16} />
              Novo Membro
            </button>
          </div>

          <UserList />
        </div>
      );
    }

    return (
      <TaskList
        onOpenTask={(task: any) => {
          setSelectedTask(task);
          setCurrentView('detail');
        }}
        viewMode={view}
        currentUser={user}
      />
    );
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-800 overflow-hidden">
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-sm transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      <aside
        className={`
          fixed inset-y-0 left-0 z-40 ${isSidebarCollapsed ? 'md:w-[92px]' : 'md:w-64'} w-64 bg-slate-900 text-white flex flex-col shadow-2xl transition-all duration-300 ease-in-out
          md:relative md:translate-x-0
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className={`border-b border-slate-800 flex items-center justify-between ${isSidebarCollapsed ? 'p-4' : 'p-6'}`}>
          <div className={`flex items-center gap-3 ${isSidebarCollapsed ? 'justify-center w-full md:w-auto' : ''}`}>
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-lg overflow-hidden shrink-0">
              <img
                src="/logo2.png"
                alt="TeleFluxo"
                className="w-[99%] h-[99%] object-contain scale-[1.0]"
              />
            </div>

            {!isSidebarCollapsed && (
              <span className="text-lg tracking-tighter font-black leading-none">
                TELE<span className="text-orange-500">FLUXO</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleSidebarCollapse}
              title={isSidebarCollapsed ? 'Expandir menu' : 'Recolher menu'}
              className="hidden md:flex text-slate-400 hover:text-white transition-colors"
            >
              {isSidebarCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="md:hidden text-slate-400 hover:text-white"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <nav className={`flex-1 ${isSidebarCollapsed ? 'p-3' : 'p-4'} space-y-1 mt-2 overflow-y-auto custom-scrollbar`}>
          <NavButton
            icon={HomeIcon}
            label="Início"
            active={currentView === 'home'}
            onClick={() => handleNavigate('home')}
            customClass="bg-orange-600 text-white shadow-lg"
          />

          {canViewExecutiveDashboard && (
            <div>
              <NavButton
                icon={ShieldCheck}
                label="Painel Diretoria"
                active={['executive_dashboard', 'avaliacoes_lojas', 'acesso_rapido_aparelhos'].includes(currentView)}
                onClick={() => handleSectionToggle('executive')}
                hasChevron
                chevronOpen={expanded.executive}
                customClass="bg-slate-800 text-white shadow-lg ring-1 ring-orange-500/30"
              />

              {expanded.executive && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem
                    label="Resumo Executivo"
                    view="executive_dashboard"
                    active={currentView === 'executive_dashboard'}
                  />

                  <SubMenuItem
                    label="Avaliações das Lojas"
                    view="avaliacoes_lojas"
                    active={currentView === 'avaliacoes_lojas'}
                  />

                  <SubMenuItem
                    label="Acesso Rápido"
                    view="acesso_rapido_aparelhos"
                    active={currentView === 'acesso_rapido_aparelhos'}
                  />
                </div>
              )}
            </div>
          )}

          {(isAdmin || isManager) && !isStoreOnly && (
            <div>
              <NavButton
                icon={LayoutDashboard}
                label="Visão Geral"
                active={currentView.startsWith('all')}
                onClick={() => handleSectionToggle('general')}
                hasChevron
                chevronOpen={expanded.general}
                customClass="bg-slate-800 text-white"
              />

              {expanded.general && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Total" view="all" active={currentView === 'all'} />
                  <SubMenuItem label="Pendentes" view="all_pending" active={currentView === 'all_pending'} />
                  <SubMenuItem label="Em Tratativa" view="all_doing" active={currentView === 'all_doing'} />
                  <SubMenuItem label="Finalizadas" view="all_done" active={currentView === 'all_done'} />
                </div>
              )}
            </div>
          )}

          {!isStoreOnly && (
            <div>
              <NavButton
                icon={FileText}
                label="Minhas Demandas"
                active={currentView.startsWith('mine_')}
                onClick={() => handleSectionToggle('mine')}
                hasChevron
                chevronOpen={expanded.mine}
                customClass="bg-slate-800 text-white"
              />

              {expanded.mine && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Pendentes" view="mine_pending" active={currentView === 'mine_pending'} />
                  <SubMenuItem label="Em Tratativa" view="mine_doing" active={currentView === 'mine_doing'} />
                  <SubMenuItem label="Finalizadas" view="mine_done" active={currentView === 'mine_done'} />
                </div>
              )}
            </div>
          )}

          {!isStoreOnly && (
            <NavButton
              icon={CheckCircle}
              label="Histórico Geral"
              active={currentView === 'completed'}
              onClick={() => handleNavigate('completed')}
              customClass="bg-orange-600 text-white shadow-lg"
            />
          )}

          {!isStoreOnly && (
            <div>
              <NavButton
                icon={MessageSquare}
                label="Informativos"
                active={currentView.startsWith('dept_')}
                onClick={() => handleSectionToggle('info')}
                hasChevron
                chevronOpen={expanded.info}
                customClass="bg-slate-800 text-white"
              />

              {expanded.info && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  {(isAdmin || isManager) ? (
                    <>
                      <SubMenuItem label="Samsung" view="dept_Samsung" active={currentView === 'dept_Samsung'} />
                      <SubMenuItem label="Tim" view="dept_Tim" active={currentView === 'dept_Tim'} />
                      <SubMenuItem label="Motorola" view="dept_Motorola" active={currentView === 'dept_Motorola'} />
                      <SubMenuItem label="Automação" view="dept_Automação" active={currentView === 'dept_Automação'} />
                      <SubMenuItem label="Financeiro" view="dept_Financeiro" active={currentView === 'dept_Financeiro'} />
                    </>
                  ) : (
                    <SubMenuItem
                      label={user.operation || "Meu Setor"}
                      view={`dept_${user.operation}`}
                      active={currentView === `dept_${user.operation}`}
                    />
                  )}
                </div>
              )}
            </div>
          )}

          {canViewComparativos && (
            <div>
              <NavButton
                icon={BarChart3}
                label="Comparativos"
                active={['comparativos_pdf', 'comparativos_fluxo', 'comparativos_cartas'].includes(currentView)}
                onClick={() => handleSectionToggle('comparativos')}
                hasChevron
                chevronOpen={expanded.comparativos}
                customClass="bg-slate-800 text-white shadow-lg"
              />

              {expanded.comparativos && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Montar Comparativo" view="comparativos_pdf" active={currentView === 'comparativos_pdf'} />
                  <SubMenuItem label="Fluxo Comparativo" view="comparativos_fluxo" active={currentView === 'comparativos_fluxo'} />
                  <SubMenuItem label="Leitura de Cartas" view="comparativos_cartas" active={currentView === 'comparativos_cartas'} />
                </div>
              )}
            </div>
          )}

          {canViewFinance && (
            <div>
              <NavButton
                icon={DollarSign}
                label="Controle Financeiro"
                active={['finance', 'controle_stone', 'recebimento_cartao'].includes(currentView)}
                onClick={() => handleSectionToggle('finance')}
                hasChevron
                chevronOpen={expanded.finance}
                customClass="bg-emerald-600 text-white shadow-lg"
              />

              {expanded.finance && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Contas a pagar e receber" view="finance" active={currentView === 'finance'} />
                  <SubMenuItem label="Conciliação Stone" view="controle_stone" active={currentView === 'controle_stone'} />
                  <SubMenuItem label="Recebimento Cartão" view="recebimento_cartao" active={currentView === 'recebimento_cartao'} />
                </div>
              )}
            </div>
          )}

          {canViewStock && (
            <div>
              <NavButton
                icon={Package}
                label="Controle de Estoque"
                active={[
                  'stock',
                  'inventory_audit',
                  'inventory_audit_dashboard',
                  'alertas_inteligentes',
                  'estoque_vendas',
                  'estoque_inteligente',
                  'auditoria_lojas',
                  'estoque_detalhado',
                  'stockout',
                  'compras_vendas',
                ].includes(currentView)}
                onClick={() => handleSectionToggle('stock')}
                hasChevron
                chevronOpen={expanded.stock}
                customClass="bg-indigo-600 text-white shadow-lg"
              />

              {expanded.stock && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Visão Geral" view="stock" active={currentView === 'stock'} />

                  <SubMenuItem
                    label="Bipador de Aparelhos"
                    view="inventory_audit"
                    active={currentView === 'inventory_audit'}
                  />

                  {canViewAuditDashboard && (
                    <SubMenuItem
                      label="BI de Conferências"
                      view="inventory_audit_dashboard"
                      active={currentView === 'inventory_audit_dashboard'}
                    />
                  )}

                  <SubMenuItem
                    label="Alertas Inteligentes"
                    view="alertas_inteligentes"
                    active={currentView === 'alertas_inteligentes'}
                  />

                  <SubMenuItem
                    label="Visão Detalhada"
                    view="estoque_detalhado"
                    active={currentView === 'estoque_detalhado'}
                  />

                  <SubMenuItem
                    label="Estoque x Vendas"
                    view="estoque_vendas"
                    active={currentView === 'estoque_vendas'}
                  />

                  {isAdmin && !isStoreOnly && (
                    <SubMenuItem
                      label="Compras x Vendas"
                      view="compras_vendas"
                      active={currentView === 'compras_vendas'}
                    />
                  )}

                  <SubMenuItem
                    label="Estoque Inteligente"
                    view="estoque_inteligente"
                    active={currentView === 'estoque_inteligente'}
                  />

                  <SubMenuItem
                    label="Stockout"
                    view="stockout"
                    active={currentView === 'stockout'}
                  />

                  {!isStoreOnly && (
                    <SubMenuItem
                      label="Auditoria Lojas"
                      view="auditoria_lojas"
                      active={currentView === 'auditoria_lojas'}
                    />
                  )}
                </div>
              )}
            </div>
          )}

          {canViewSales && (
            <div>
              <NavButton
                icon={TrendingUp}
                label="Controle de Vendas"
                active={['sales_dash', 'comparativo'].includes(currentView)}
                onClick={() => handleSectionToggle('sales')}
                hasChevron
                chevronOpen={expanded.sales}
                customClass="bg-blue-600 text-white shadow-lg"
              />

              {expanded.sales && !isSidebarCollapsed && (
                <div className="mt-1 space-y-1">
                  <SubMenuItem label="Vendas Mensal" view="sales_dash" active={currentView === 'sales_dash'} />
                  <SubMenuItem label="Vendas anuais" view="comparativo" active={currentView === 'comparativo'} />
                </div>
              )}
            </div>
          )}

          {canViewSales && (
            <NavButton
              icon={Tag}
              label="Tabelas de Preço"
              active={currentView === 'price_table'}
              onClick={() => handleNavigate('price_table')}
              customClass="bg-indigo-500 text-white shadow-lg"
            />
          )}

          <NavButton
            icon={Calendar}
            label="Agenda Pessoal"
            active={currentView === 'agenda'}
            onClick={() => handleNavigate('agenda')}
            customClass="bg-orange-600 text-white shadow-lg"
          />

          {(isAdmin || isManager) && (
            <NavButton
              icon={BarChart3}
              label="Produtividade Equipe"
              active={currentView === 'manager_dash'}
              onClick={() => handleNavigate('manager_dash')}
              customClass="bg-orange-600 text-white shadow-lg"
            />
          )}

          <NavButton
            icon={MessageSquare}
            label="Solicitações"
            active={currentView === 'solicitacoes'}
            onClick={() => handleNavigate('solicitacoes')}
            customClass="bg-fuchsia-600 text-white shadow-lg"
          />

          <NavButton
            icon={Users}
            label="RH"
            active={currentView === 'rh'}
            onClick={() => handleNavigate('rh')}
            customClass="bg-slate-700 text-white shadow-lg"
          />

          {canViewTeam && (
            <div className={`pt-4 mt-4 border-t border-slate-800 ${isSidebarCollapsed ? 'px-0' : ''}`}>
              {!isSidebarCollapsed && (
                <p className="px-3 text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">
                  Configurações
                </p>
              )}

              <NavButton
                icon={Users}
                label="Equipe"
                active={currentView === 'team'}
                onClick={() => handleNavigate('team')}
                customClass="bg-slate-800 text-white"
              />
            </div>
          )}
        </nav>

        <div className={`border-t border-slate-800 bg-slate-950/20 ${isSidebarCollapsed ? 'p-3 flex justify-center' : 'p-4 flex items-center gap-3'}`}>
          <div className="w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center text-sm font-black border-2 border-slate-700 shadow-inner shrink-0">
            {user?.name?.charAt(0)}
          </div>

          {!isSidebarCollapsed && (
            <div className="flex-1 overflow-hidden">
              <span className="text-sm font-bold truncate block uppercase tracking-tighter">
                {user?.name}
              </span>

              <span className="text-[9px] text-slate-500 font-black uppercase truncate block tracking-widest italic">
                {user?.role}
              </span>
            </div>
          )}

          <button
            onClick={handleLogout}
            title="Sair"
            className="text-slate-500 hover:text-red-500 shrink-0"
          >
            <LogOut size={18} />
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden w-full">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-8 shadow-sm shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="md:hidden text-slate-600 hover:text-orange-600 transition-colors"
            >
              <Menu size={24} />
            </button>

            <button
              onClick={toggleSidebarCollapse}
              className="hidden md:flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-900 hover:border-slate-300 transition-colors"
              title={isSidebarCollapsed ? 'Expandir menu' : 'Recolher menu'}
            >
              {isSidebarCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            </button>

            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
              <span className="hidden md:inline">Grupo Telecel •</span>
              {currentViewLabel}
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-3">
            <GlobalSearch
              currentUser={user}
              onNavigate={handleNavigate}
              onOpenStore={(store) => {
                handleNavigate('home');
                window.setTimeout(() => {
                  window.dispatchEvent(
                    new CustomEvent('telefluxo:open-store', { detail: { store } })
                  );
                }, 80);
              }}
            />
            {canUseClarkDiretoria && (
              <Clark
                currentUser={user}
                placement="header"
                onNavigateContracts={() => handleNavigate('contract_analyzer')}
                onNavigateOnlinePrices={() => handleNavigate('online_prices')}
              />
            )}
            <AlertCenterBell
              currentUser={user}
              onOpenCenter={() => handleNavigate('alertas_inteligentes')}
            />
            <NotificationBell currentUser={user} />
          </div>
        </header>

        <div className="flex-1 overflow-hidden relative flex flex-col">
          {(
            mountedViews.includes(currentView)
              ? mountedViews
              : [...mountedViews, currentView]
          ).map((view) => (
            <div
              key={view}
              className={
                view === currentView
                  ? 'contents'
                  : 'hidden'
              }
              aria-hidden={view !== currentView}
            >
              {renderViewContent(view)}
            </div>
          ))}
        </div>
      </main>

      <NewUserModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
      />

      {isNewTaskModalOpen && (
        <NewTaskModal
          isOpen={isNewTaskModalOpen}
          onClose={() => setIsNewTaskModalOpen(false)}
          currentUser={user}
          onTaskCreated={() => {
            setIsNewTaskModalOpen(false);
            window.location.reload();
          }}
        />
      )}
    </div>
  );
}
export default App;
