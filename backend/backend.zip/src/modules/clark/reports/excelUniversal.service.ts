import ExcelJS from 'exceljs';

type GerarExcelUniversalInput = {
  titulo: string;
  pergunta?: string;
  dados: any;
};

type SheetColumn = {
  header: string;
  key: string;
  width?: number;
};

const TOOL_LABELS: Record<string, string> = {
  consultar_estoque_produto: 'Estoque de produto específico',
  consultar_ranking_estoque: 'Ranking de estoque',
  consultar_vendas_por_loja: 'Vendas por loja',
  consultar_vendas_por_vendedor: 'Vendas por vendedor',
  consultar_vendas_por_categoria: 'Vendas por categoria',
  consultar_vendas_resumo: 'Resumo de vendas',
  consultar_seguros_por_loja: 'Seguros por loja',
  consultar_seguros_por_vendedor: 'Seguros por vendedor',
  executar_sql_analitico: 'Consulta analítica',
  gerar_relatorio_executivo: 'Relatório executivo',
  consultar_relatorio_vendas: 'Relatório de vendas',
};

function toNumber(value: any, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function asArray(value: any): any[] {
  return Array.isArray(value) ? value : [];
}

function sanitizeSheetName(name: string): string {
  const clean = String(name || 'Dados')
    .replace(/[\\/*?:[\]]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 31);

  return clean || 'Dados';
}

function uniqueSheetName(workbook: ExcelJS.Workbook, name: string): string {
  const base = sanitizeSheetName(name);
  const existing = new Set(workbook.worksheets.map((sheet) => sheet.name));

  if (!existing.has(base)) return base;

  for (let index = 2; index <= 99; index += 1) {
    const suffix = ` ${index}`;
    const candidate = sanitizeSheetName(`${base.slice(0, 31 - suffix.length)}${suffix}`);
    if (!existing.has(candidate)) return candidate;
  }

  return sanitizeSheetName(`${base.slice(0, 25)} ${Date.now()}`); 
}

function stringifyCell(value: any): any {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number' || typeof value === 'boolean' || value instanceof Date) return value;
  if (typeof value === 'string') return value;

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function getToolResults(dados: any): any[] {
  if (Array.isArray(dados?.toolResults)) return dados.toolResults;
  if (Array.isArray(dados?.origem?.toolResults)) return dados.origem.toolResults;
  if (Array.isArray(dados?.dados?.toolResults)) return dados.dados.toolResults;
  return [];
}

function getToolResult(dados: any, toolName: string): any | null {
  const toolResults = getToolResults(dados);
  const found = toolResults.find((item: any) => item?.tool === toolName && item?.ok !== false);
  return found?.result || null;
}

function flattenObject(row: any): Record<string, any> {
  if (!row || typeof row !== 'object') return { valor: row };

  const output: Record<string, any> = {};

  for (const [key, value] of Object.entries(row)) {
    if (value === null || value === undefined) {
      output[key] = '';
    } else if (Array.isArray(value)) {
      output[key] = value
        .map((item) => {
          if (item && typeof item === 'object') {
            return Object.entries(item)
              .map(([k, v]) => `${k}: ${stringifyCell(v)}`)
              .join(', ');
          }
          return stringifyCell(item);
        })
        .join(' | ');
    } else if (typeof value === 'object') {
      output[key] = stringifyCell(value);
    } else {
      output[key] = value;
    }
  }

  return output;
}

function inferColumns(rows: any[]): SheetColumn[] {
  const keys = new Set<string>();

  for (const row of rows.slice(0, 100)) {
    const flat = flattenObject(row);
    Object.keys(flat).forEach((key) => keys.add(key));
  }

  const columns = Array.from(keys).map((key) => ({
    header: key
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (letter) => letter.toUpperCase()),
    key,
    width: Math.min(Math.max(key.length + 8, 16), 42),
  }));

  return columns.length ? columns : [{ header: 'Valor', key: 'valor', width: 30 }];
}

function applySheetStyle(sheet: ExcelJS.Worksheet) {
  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' };

  sheet.views = [{ state: 'frozen', ySplit: 1 }];

  sheet.eachRow((row) => {
    row.eachCell((cell) => {
      cell.alignment = {
        vertical: 'top',
        wrapText: true,
      };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' },
      };
    });
  });
}

function addRowsSheet(
  workbook: ExcelJS.Workbook,
  name: string,
  rowsInput: any[],
  preferredColumns?: SheetColumn[]
) {
  const rows = asArray(rowsInput).map(flattenObject);
  const sheet = workbook.addWorksheet(uniqueSheetName(workbook, name));

  const columns = preferredColumns && preferredColumns.length ? preferredColumns : inferColumns(rows);
  sheet.columns = columns;

  if (rows.length) {
    for (const row of rows) {
      const prepared: Record<string, any> = {};
      for (const col of columns) {
        prepared[col.key] = stringifyCell(row[col.key]);
      }
      sheet.addRow(prepared);
    }
  } else {
    sheet.addRow(
      Object.fromEntries(columns.map((col) => [col.key, 'Sem dados encontrados']))
    );
  }

  applySheetStyle(sheet);
  return sheet;
}

function addResumoSheet(
  workbook: ExcelJS.Workbook,
  input: GerarExcelUniversalInput
) {
  const sheet = workbook.addWorksheet(uniqueSheetName(workbook, 'Resumo'));

  const toolResults = getToolResults(input.dados);
  const periodo = input.dados?.periodo || input.dados?.resumo?.periodo || input.dados?.origem?.periodo || null;

  sheet.columns = [
    { header: 'Campo', key: 'campo', width: 28 },
    { header: 'Valor', key: 'valor', width: 90 },
  ];

  sheet.addRow({ campo: 'Título', valor: input.titulo || 'Exportação Clark IA' });
  sheet.addRow({ campo: 'Pergunta', valor: input.pergunta || '' });
  sheet.addRow({ campo: 'Gerado em', valor: new Date().toLocaleString('pt-BR') });

  if (periodo) {
    sheet.addRow({ campo: 'Período', valor: periodo.descricao || `${periodo.inicio || ''} até ${periodo.fim || ''}` });
    sheet.addRow({ campo: 'Data inicial', valor: periodo.inicio || '' });
    sheet.addRow({ campo: 'Data final', valor: periodo.fim || '' });
  }

  if (toolResults.length) {
    sheet.addRow({
      campo: 'Ferramentas',
      valor: toolResults
        .map((item: any) => TOOL_LABELS[item?.tool] || item?.tool)
        .filter(Boolean)
        .join(', '),
    });
  }

  const resumo = input.dados?.resumo || getToolResult(input.dados, 'consultar_vendas_resumo');
  if (resumo) {
    sheet.addRow({ campo: 'Total vendas', valor: resumo.total_vendas_formatado || resumo.vendasTotais || resumo.total_vendas || '' });
    sheet.addRow({ campo: 'Peças vendidas', valor: resumo.total_pecas || resumo.pecasVendidas || '' });
    sheet.addRow({ campo: 'Ticket médio', valor: resumo.ticket_medio_formatado || resumo.ticketMedio || resumo.ticket_medio || '' });
  }

  applySheetStyle(sheet);
}

function addEstoqueProduto(workbook: ExcelJS.Workbook, result: any) {
  const produtos = asArray(result?.produtos);
  const lojas = asArray(result?.lojas || result?.lojasComEstoque);

  addRowsSheet(workbook, 'Produtos', produtos, [
    { header: 'Produto', key: 'descricao', width: 42 },
    { header: 'Referência', key: 'referencia', width: 20 },
    { header: 'Código', key: 'codigo_produto', width: 20 },
    { header: 'Categoria', key: 'categoria', width: 18 },
    { header: 'Quantidade total', key: 'quantidade_total', width: 18 },
  ]);

  addRowsSheet(workbook, 'Lojas com Estoque', lojas, [
    { header: 'Loja', key: 'loja', width: 32 },
    { header: 'CNPJ', key: 'cnpj_empresa', width: 20 },
    { header: 'Produto', key: 'descricao', width: 42 },
    { header: 'Referência', key: 'referencia', width: 20 },
    { header: 'Quantidade', key: 'quantidade', width: 14 },
    { header: 'Categoria', key: 'categoria', width: 18 },
  ]);
}

function addRankingEstoque(workbook: ExcelJS.Workbook, result: any) {
  const ranking = asArray(result?.ranking);
  const lojasPorProduto: any[] = [];

  for (const item of ranking) {
    const lojas = asArray(item?.lojas || item?.principais_lojas || item?.lojas_com_estoque);

    for (const loja of lojas) {
      lojasPorProduto.push({
        produto: item.descricao || item.produto || item.nome || '',
        referencia: item.referencia || item.codigo_produto || '',
        quantidade_total: toNumber(item.quantidade_total ?? item.quantidade ?? item.estoque),
        loja: loja.loja || loja.nome_loja || loja.nome || '',
        cnpj_empresa: loja.cnpj_empresa || loja.cnpj || '',
        quantidade_loja: toNumber(loja.quantidade ?? loja.estoque ?? loja.qtd),
      });
    }
  }

  addRowsSheet(workbook, 'Ranking Estoque', ranking, [
    { header: 'Posição', key: 'posicao', width: 10 },
    { header: 'Produto', key: 'descricao', width: 44 },
    { header: 'Referência', key: 'referencia', width: 20 },
    { header: 'Código', key: 'codigo_produto', width: 20 },
    { header: 'Categoria', key: 'categoria', width: 18 },
    { header: 'Quantidade total', key: 'quantidade_total', width: 18 },
    { header: 'Lojas', key: 'lojas', width: 70 },
  ]);

  addRowsSheet(workbook, 'Lojas por Produto', lojasPorProduto.length ? lojasPorProduto : ranking, [
    { header: 'Produto', key: 'produto', width: 44 },
    { header: 'Referência', key: 'referencia', width: 20 },
    { header: 'Quantidade total', key: 'quantidade_total', width: 18 },
    { header: 'Loja', key: 'loja', width: 32 },
    { header: 'CNPJ', key: 'cnpj_empresa', width: 20 },
    { header: 'Quantidade loja', key: 'quantidade_loja', width: 18 },
  ]);
}

function addVendasResumo(workbook: ExcelJS.Workbook, result: any) {
  const rows = [
    {
      periodo: result?.periodo?.descricao || '',
      total_vendas: result?.total_vendas,
      total_vendas_formatado: result?.total_vendas_formatado,
      total_pecas: result?.total_pecas,
      quantidade_registros: result?.quantidade_registros,
      ticket_medio: result?.ticket_medio,
      ticket_medio_formatado: result?.ticket_medio_formatado,
      lojas_analisadas: result?.lojas_analisadas,
    },
  ];

  addRowsSheet(workbook, 'Resumo Vendas', rows);
}

function addRelatorioExecutivo(workbook: ExcelJS.Workbook, result: any) {
  if (result?.resumo) addVendasResumo(workbook, result.resumo);
  if (Array.isArray(result?.vendasPorLoja || result?.lojas)) addRowsSheet(workbook, 'Vendas por Loja', result.vendasPorLoja || result.lojas);
  if (Array.isArray(result?.vendasPorVendedor || result?.vendedores)) addRowsSheet(workbook, 'Vendas por Vendedor', result.vendasPorVendedor || result.vendedores);
  if (Array.isArray(result?.segurosPorLoja || result?.segurosLojas)) addRowsSheet(workbook, 'Seguros por Loja', result.segurosPorLoja || result.segurosLojas);
  if (Array.isArray(result?.segurosPorVendedor || result?.segurosVendedores)) addRowsSheet(workbook, 'Seguros por Vendedor', result.segurosPorVendedor || result.segurosVendedores);
  if (Array.isArray(result?.estoqueDestaque || result?.estoque)) addRowsSheet(workbook, 'Ranking Estoque', result.estoqueDestaque || result.estoque);
  if (result?.relatorio) {
    addRowsSheet(workbook, 'Relatório', [{ relatorio: result.relatorio }], [
      { header: 'Relatório', key: 'relatorio', width: 120 },
    ]);
  }
}

function addGenericKnownData(workbook: ExcelJS.Workbook, dados: any) {
  if (Array.isArray(dados?.vendasPorLoja)) addRowsSheet(workbook, 'Vendas por Loja', dados.vendasPorLoja);
  if (Array.isArray(dados?.vendasPorVendedor)) addRowsSheet(workbook, 'Vendas por Vendedor', dados.vendasPorVendedor);
  if (Array.isArray(dados?.estoqueDestaque)) addRowsSheet(workbook, 'Ranking Estoque', dados.estoqueDestaque);
  if (Array.isArray(dados?.segurosPorLoja)) addRowsSheet(workbook, 'Seguros por Loja', dados.segurosPorLoja);
  if (Array.isArray(dados?.segurosPorVendedor)) addRowsSheet(workbook, 'Seguros por Vendedor', dados.segurosPorVendedor);
}

function addToolSheets(workbook: ExcelJS.Workbook, dados: any) {
  const toolResults = getToolResults(dados);

  for (const toolResult of toolResults) {
    if (!toolResult || toolResult.ok === false) continue;

    const tool = String(toolResult.tool || '');
    const result = toolResult.result || {};

    if (tool === 'consultar_estoque_produto') {
      addEstoqueProduto(workbook, result);
      continue;
    }

    if (tool === 'consultar_ranking_estoque') {
      addRankingEstoque(workbook, result);
      continue;
    }

    if (tool === 'consultar_vendas_resumo') {
      addVendasResumo(workbook, result);
      continue;
    }

    if (tool === 'consultar_vendas_por_loja') {
      addRowsSheet(workbook, 'Vendas por Loja', result.ranking || result.lojas || result.rows || []);
      continue;
    }

    if (tool === 'consultar_vendas_por_vendedor') {
      addRowsSheet(workbook, 'Vendas por Vendedor', result.ranking || result.vendedores || result.rows || []);
      continue;
    }

    if (tool === 'consultar_vendas_por_categoria') {
      addRowsSheet(workbook, 'Vendas por Categoria', result.ranking || result.categorias || result.rows || []);
      continue;
    }

    if (tool === 'consultar_seguros_por_loja') {
      addRowsSheet(workbook, 'Seguros por Loja', result.ranking || result.lojas || result.rows || []);
      continue;
    }

    if (tool === 'consultar_seguros_por_vendedor') {
      addRowsSheet(workbook, 'Seguros por Vendedor', result.ranking || result.vendedores || result.rows || []);
      continue;
    }

    if (tool === 'executar_sql_analitico') {
      addRowsSheet(workbook, 'Consulta Analítica', result.rows || []);
      continue;
    }

    if (tool === 'gerar_relatorio_executivo' || tool === 'consultar_relatorio_vendas') {
      addRelatorioExecutivo(workbook, result);
    }
  }
}

function workbookHasOnlyResumo(workbook: ExcelJS.Workbook) {
  return workbook.worksheets.length <= 1;
}

export async function gerarExcelUniversalClark(
  input: GerarExcelUniversalInput
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();

  workbook.creator = 'Clark IA - TeleFluxo';
  workbook.created = new Date();

  addResumoSheet(workbook, input);
  addToolSheets(workbook, input.dados);
  addGenericKnownData(workbook, input.dados);

  if (workbookHasOnlyResumo(workbook)) {
    const rows =
      Array.isArray(input.dados)
        ? input.dados
        : Array.isArray(input.dados?.rows)
          ? input.dados.rows
          : Array.isArray(input.dados?.dados)
            ? input.dados.dados
            : [input.dados || {}];

    addRowsSheet(workbook, 'Dados Brutos', rows);
  }

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}
