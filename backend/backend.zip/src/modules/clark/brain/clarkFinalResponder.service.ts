import { GoogleGenAI } from '@google/genai';
import {
  ClarkAgentPlan,
  ClarkToolResult,
  ClarkVerificationResult,
} from '../agent/clarkAgent.types';
import { ClarkPeriodo } from '../clark.types';
import { formatBRL } from '../../intent/extractFilters';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

const genAI = GEMINI_API_KEY ? new GoogleGenAI({ apiKey: GEMINI_API_KEY }) : null;

function toNumber(v: any, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clip(value: any, max = 26000) {
  const text = String(value ?? '');
  return text.length > max ? `${text.slice(0, max)}... [cortado]` : text;
}

function isBadAnswer(text: string) {
  const s = String(text || '').trim();

  return (
    !s ||
    s === '{}' ||
    s === '[]' ||
    s.toLowerCase() === 'null' ||
    s.startsWith('{"') ||
    s.startsWith('{\n') ||
    s.includes('exactDictionaryCandidates') ||
    s.includes('similarDictionaryCandidates') ||
    s.includes('toolResults') ||
    s.includes('"result"') ||
    s.includes('"args"')
  );
}

function limparDescricaoProduto(descricao: any) {
  return String(descricao || '')
    .replace(/\bSM-[A-Z0-9]{6,}\b/gi, '')
    .replace(/\b[A-Z]{1,4}-?[A-Z0-9]{8,}\b/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function lojasFormatadasTodas(lojas: any[]) {
  if (!Array.isArray(lojas) || !lojas.length) {
    return '   • Sem lojas com quantidade positiva';
  }

  return lojas
    .map((l) => {
      const loja = String(l?.loja || '').trim() || 'Loja não informada';
      return `   • ${loja}: ${toNumber(l?.quantidade)} un.`;
    })
    .join('\n');
}

function resumoLojasRanking(lojas: any[], limit = 8) {
  if (!Array.isArray(lojas) || !lojas.length) {
    return 'sem lojas com quantidade positiva';
  }

  const top = lojas
    .slice(0, limit)
    .map((l) => {
      const loja = String(l?.loja || '').trim() || 'Loja não informada';
      return `${loja}: ${toNumber(l?.quantidade)} un.`;
    })
    .join(', ');

  const resto = lojas.length > limit ? ` (+${lojas.length - limit} lojas)` : '';

  return `${top}${resto}`;
}

function montarCriterioProduto(p: any, termoPesquisado?: string) {
  const partes = [
    p?.family || p?.model || termoPesquisado,
    p?.storage,
    p?.color,
    p?.category ? `categoria ${p.category}` : null,
  ].filter(Boolean);

  return partes.join(', ');
}

function normalizarNivelBuscaProduto(first: any) {
  const p = first?.produto_planejado || {};

  const temMemoria = Boolean(p.storage);
  const temCor = Boolean(p.color);

  const nivelInformado =
    first?.nivel_busca ||
    first?.searchLevel ||
    first?.search_level ||
    p?.nivel_busca ||
    p?.searchLevel ||
    p?.search_level ||
    '';

  const nivel = String(nivelInformado).toLowerCase();

  if (
    nivel.includes('familia') ||
    nivel.includes('família') ||
    nivel.includes('family') ||
    nivel.includes('linha') ||
    nivel.includes('modelo_aberto')
  ) {
    return 'familia';
  }

  if (
    nivel.includes('memoria') ||
    nivel.includes('memória') ||
    nivel.includes('storage') ||
    nivel.includes('intermediaria') ||
    nivel.includes('intermediária') ||
    nivel.includes('intermediario') ||
    nivel.includes('intermediário')
  ) {
    return 'memoria';
  }

  if (
    nivel.includes('exata') ||
    nivel.includes('exato') ||
    nivel.includes('specific') ||
    nivel.includes('specifico') ||
    nivel.includes('especifico') ||
    nivel.includes('específico')
  ) {
    return 'exato';
  }

  if (!temMemoria && !temCor) return 'familia';
  if (temMemoria && !temCor) return 'memoria';

  return 'exato';
}

function tituloProduto(first: any) {
  const p = first?.produto_planejado || {};

  return String(p.family || p.model || first?.termo_pesquisado || 'produto solicitado')
    .trim()
    .toUpperCase();
}

function subtituloProduto(first: any) {
  const p = first?.produto_planejado || {};

  const partes = [
    p.storage,
    p.color,
    p.category ? `categoria ${p.category}` : null,
  ].filter(Boolean);

  if (!partes.length) return '';

  return partes.join(' • ').toUpperCase();
}

function formatarListaProdutosEstoque(params: {
  produtos: any[];
  first: any;
  nivelBusca: string;
}) {
  const { produtos, first, nivelBusca } = params;

  const linhas = produtos.map((item: any, i: number) => {
    const descricaoLimpa = limparDescricaoProduto(item?.descricao);
    const lojas = item?.lojas || item?.principais_lojas || [];

    return [
      `${i + 1}. ${descricaoLimpa}`,
      `   Total: ${toNumber(item?.quantidade_total)} un.`,
      `   Lojas com estoque:`,
      lojasFormatadasTodas(lojas),
    ].join('\n');
  });

  const total = produtos.reduce((acc: number, item: any) => {
    return acc + toNumber(item?.quantidade_total);
  }, 0);

  const titulo = tituloProduto(first);
  const subtitulo = subtituloProduto(first);

  if (nivelBusca === 'familia') {
    return [
      `📦 Estoque encontrado — ${titulo}`,
      subtitulo ? `Filtro: ${subtitulo}` : '',
      `Total geral: ${total} un.`,
      `Variações encontradas: ${produtos.length}`,
      '',
      `Variações disponíveis:`,
      '',
      ...linhas,
    ]
      .filter((linha) => linha !== '')
      .join('\n');
  }

  if (nivelBusca === 'memoria') {
    return [
      `📦 Estoque encontrado — ${titulo}`,
      subtitulo ? `Filtro: ${subtitulo}` : '',
      `Total geral: ${total} un.`,
      `Cores/variações encontradas: ${produtos.length}`,
      '',
      `Variações disponíveis:`,
      '',
      ...linhas,
    ]
      .filter((linha) => linha !== '')
      .join('\n');
  }

  return [
    `📦 Estoque encontrado — ${titulo}`,
    subtitulo ? `Filtro: ${subtitulo}` : '',
    `Total geral: ${total} un.`,
    '',
    ...linhas,
  ]
    .filter((linha) => linha !== '')
    .join('\n');
}

export function respostaLocalExecutiva(params: {
  plan: ClarkAgentPlan;
  results: ClarkToolResult[];
  periodo: ClarkPeriodo;
}) {
  const success = params.results.find((r) => r.ok && r.result);
  const first = success?.result;
  const tool = success?.tool;

  if (!first) {
    const erro = params.results.find((r) => r.error)?.error;

    return erro
      ? `Não consegui concluir a consulta: ${erro}. Nenhum dado foi inventado.`
      : 'Não encontrei dados suficientes para responder com segurança. Nenhum dado foi inventado.';
  }

  if (tool === 'responder_ajuda') {
    return (
      first.mensagem ||
      'Posso analisar vendas, estoque, lojas, vendedores, categorias, seguros, crescimento e relatórios executivos.'
    );
  }

  if (tool === 'consultar_ranking_estoque') {
    const ranking = Array.isArray(first.ranking) ? first.ranking : [];

    if (!ranking.length) {
      return `Não encontrei estoque positivo para a categoria ${first.categoria_solicitada || 'solicitada'}.`;
    }

    const linhas = ranking.map((item: any) => {
      const descricaoLimpa = limparDescricaoProduto(item?.descricao);

      return [
        `${item?.posicao || ''}. ${descricaoLimpa}`,
        `   Total: ${toNumber(item?.quantidade_total)} un.`,
        `   Principais lojas: ${resumoLojasRanking(item?.principais_lojas || item?.lojas || [], 8)}`,
      ].join('\n');
    });

    return [
      `🏆 Ranking de estoque${first.categoria_solicitada ? ` — ${first.categoria_solicitada}` : ''}`,
      '',
      `Modelos encontrados: ${ranking.length}`,
      '',
      ...linhas,
    ].join('\n');
  }

  if (tool === 'consultar_estoque_produto') {
    const produtos = Array.isArray(first.produtos) ? first.produtos : [];
    const p = first.produto_planejado || {};
    const criterio = montarCriterioProduto(p, first.termo_pesquisado);
    const nivelBusca = normalizarNivelBuscaProduto(first);

    if (!produtos.length || first.produto_nao_encontrado_exato) {
      if (nivelBusca === 'familia') {
        return [
          `Não encontrei estoque para ${p.family || p.model || first.termo_pesquisado || 'a família solicitada'}.`,
          'Como você não informou memória nem cor, procurei a família inteira e não trouxe variações fora dela.',
        ].join('\n');
      }

      if (nivelBusca === 'memoria') {
        return [
          `Não encontrei estoque para ${criterio || first.termo_pesquisado || 'o produto solicitado'}.`,
          'Como você informou memória, procurei essa família com essa memória em todas as cores disponíveis.',
        ].join('\n');
      }

      return [
        `Não encontrei estoque exato para ${criterio || first.termo_pesquisado || 'o produto solicitado'}.`,
        'Não retornei modelos parecidos porque produto específico exige bater os filtros informados pelo usuário.',
      ].join('\n');
    }

    return formatarListaProdutosEstoque({
      produtos,
      first,
      nivelBusca,
    });
  }

  if (tool === 'consultar_vendas_resumo') {
    return [
      `💰 Resumo de vendas — ${first.periodo?.descricao || params.periodo.descricao}`,
      '',
      `Total vendido: ${first.total_vendas_formatado || formatBRL(first.total_vendas)}`,
      `Peças vendidas: ${toNumber(first.total_pecas)}`,
      `Ticket médio: ${first.ticket_medio_formatado || formatBRL(first.ticket_medio)}`,
    ].join('\n');
  }

  if (tool === 'consultar_vendas_por_loja') {
    const ranking = Array.isArray(first.ranking) ? first.ranking : [];

    if (!ranking.length) {
      return `Não encontrei vendas por loja no período ${first.periodo?.descricao || params.periodo.descricao}.`;
    }

    const linhas = ranking.map((item: any) => {
      return [
        `${item?.posicao || ''}. ${item?.loja}`,
        `   Total: ${item?.total_vendas_formatado || formatBRL(item?.total_vendas)}`,
        `   Peças: ${toNumber(item?.total_pecas)}`,
      ].join('\n');
    });

    return [
      `💰 Vendas por loja — ${first.periodo?.descricao || params.periodo.descricao}`,
      '',
      `Lojas encontradas: ${ranking.length}`,
      '',
      ...linhas,
    ].join('\n');
  }

  if (tool === 'consultar_vendas_por_vendedor') {
    const ranking = Array.isArray(first.ranking) ? first.ranking : [];

    if (!ranking.length) {
      return `Não encontrei vendas por vendedor no período ${first.periodo?.descricao || params.periodo.descricao}.`;
    }

    const linhas = ranking.map((item: any) => {
      return [
        `${item?.posicao || ''}. ${item?.vendedor}`,
        `   Loja: ${item?.loja || 'Não informada'}`,
        `   Total: ${item?.total_vendas_formatado || formatBRL(item?.total_vendas)}`,
        `   Peças: ${toNumber(item?.total_pecas)}`,
      ].join('\n');
    });

    return [
      `👤 Ranking de vendedores — ${first.periodo?.descricao || params.periodo.descricao}`,
      '',
      `Vendedores encontrados: ${ranking.length}`,
      '',
      ...linhas,
    ].join('\n');
  }

  if (tool === 'consultar_vendas_por_categoria') {
    const ranking = Array.isArray(first.ranking) ? first.ranking : [];

    if (!ranking.length) {
      return `Não encontrei vendas por categoria no período ${first.periodo?.descricao || params.periodo.descricao}.`;
    }

    const linhas = ranking.map((item: any) => {
      return [
        `${item?.posicao || ''}. ${item?.categoria}`,
        `   Total: ${item?.total_vendas_formatado || formatBRL(item?.total_vendas)}`,
        `   Peças: ${toNumber(item?.total_pecas)}`,
      ].join('\n');
    });

    return [
      `📊 Vendas por categoria — ${first.periodo?.descricao || params.periodo.descricao}`,
      '',
      `Categorias encontradas: ${ranking.length}`,
      '',
      ...linhas,
    ].join('\n');
  }

  if (tool === 'consultar_seguros_por_vendedor' || tool === 'consultar_seguros_por_loja') {
    const ranking = Array.isArray(first.ranking) ? first.ranking : [];

    if (!ranking.length) {
      return `Não encontrei seguros no período ${first.periodo?.descricao || params.periodo.descricao}.`;
    }

    const linhas = ranking.map((item: any) => {
      return [
        `${item?.posicao || ''}. ${item?.vendedor || item?.loja}`,
        `   Total: ${item?.seguros_total_formatado || formatBRL(item?.seguros_total)}`,
        `   Quantidade: ${toNumber(item?.seguros_qtd)}`,
      ].join('\n');
    });

    return [
      `🛡️ Ranking de seguros — ${first.periodo?.descricao || params.periodo.descricao}`,
      '',
      `Registros encontrados: ${ranking.length}`,
      '',
      ...linhas,
    ].join('\n');
  }

  if (tool === 'gerar_relatorio_executivo') {
    return String(first.relatorio || first.resumo || '').trim() || clip(JSON.stringify(first, null, 2), 6000);
  }

  if (tool === 'executar_sql_analitico') {
    const rows = Array.isArray(first.rows) ? first.rows : [];

    if (!rows.length) {
      return 'Executei a consulta analítica, mas não encontrei registros para responder com segurança.';
    }

    const linhas = rows.slice(0, 15).map((row: any, i: number) => {
      return `${i + 1}. ${Object.entries(row)
        .slice(0, 8)
        .map(([k, v]) => `${k}: ${v}`)
        .join(' | ')}`;
    });

    return [
      `Consulta analítica concluída. Encontrei ${first.total_linhas || rows.length} linha(s).`,
      '',
      ...linhas,
    ].join('\n');
  }

  return clip(JSON.stringify(first, null, 2), 5000);
}

function promptFinal(params: {
  pergunta: string;
  plan: ClarkAgentPlan;
  results: ClarkToolResult[];
  verifier: ClarkVerificationResult;
  fallback: string;
}) {
  return `Você é a Clark, IA analítica executiva do TeleFluxo.

Responda em português do Brasil com clareza, precisão e formato profissional.

PERGUNTA:
${params.pergunta}

PLANO EXECUTADO:
${JSON.stringify(params.plan, null, 2)}

VALIDAÇÃO:
${JSON.stringify(params.verifier, null, 2)}

DADOS REAIS DAS FERRAMENTAS:
${clip(
  JSON.stringify(
    params.results.map((r) => ({
      tool: r.tool,
      ok: r.ok,
      args: r.args,
      result: r.result,
      error: r.error,
    })),
    null,
    2,
  ),
  30000,
)}

FALLBACK SEGURO:
${params.fallback}

REGRAS OBRIGATÓRIAS:
- Nunca invente números, lojas, produtos, vendedores ou períodos.
- Nunca mostre JSON bruto, trace, candidates, score, args ou nome de ferramenta interna.
- Nunca mostre referência técnica/código do produto, como "SM-A566EZKSZTO", salvo se o usuário pedir código/referência.
- Para consulta de estoque de produto, mostre TODAS as lojas com estoque. Não use "+N lojas com estoque".
- Não trate toda menção de produto como produto exato.
- Família apenas, exemplo "Galaxy A56", deve buscar todas as variações da família.
- Família + memória, exemplo "Galaxy A56 128GB", deve buscar todas as cores dessa memória.
- Família + cor, exemplo "Galaxy A56 Preto", deve buscar todas as memórias dessa cor.
- Família + memória + cor, exemplo "Galaxy A56 128GB Preto", deve buscar a variação específica.
- Referência/código, exemplo "SM-A566", deve ser busca específica.
- Responda com layout limpo, usando título, total geral, variações e todas as lojas.
- Se não houver dado exato, diga claramente.
- Se o fallback já estiver bom e fiel aos dados, apenas melhore a formatação sem mudar números.

Se não conseguir melhorar o fallback com segurança, retorne o fallback reformatado.`;
}

export async function responderFinalClark(params: {
  pergunta: string;
  plan: ClarkAgentPlan;
  results: ClarkToolResult[];
  verifier: ClarkVerificationResult;
  periodo: ClarkPeriodo;
}): Promise<{ text: string; usedGemini: boolean }> {
  const fallback = respostaLocalExecutiva({
    plan: params.plan,
    results: params.results,
    periodo: params.periodo,
  });

  if (!genAI) {
    return {
      text: fallback,
      usedGemini: false,
    };
  }

  try {
    const response = await genAI.models.generateContent({
      model: GEMINI_MODEL,
      contents: promptFinal({
        pergunta: params.pergunta,
        plan: params.plan,
        results: params.results,
        verifier: params.verifier,
        fallback,
      }),
      config: {
        temperature: 0.25,
      } as any,
    });

    const text = String(response.text || '').trim();

    if (isBadAnswer(text)) {
      return {
        text: fallback,
        usedGemini: false,
      };
    }

    return {
      text,
      usedGemini: true,
    };
  } catch (error) {
    console.warn('⚠️ Responder Gemini falhou. Usando fallback local:', error);

    return {
      text: fallback,
      usedGemini: false,
    };
  }
}